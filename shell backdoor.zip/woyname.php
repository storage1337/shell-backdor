<html>
<title>KRONKZ</title>
<link REL="SHORTCUT ICON" HREF="http://ppa.scisoc.or.th/.../indonesia.gif">

<style>
body { background	: #000; font-family	: Courier new; text-align	: center; color		: #fff; } pre { margin-top: 2%; } 
</style></head>
<body><pre><i>
</pre></i><br/>
<font color='red'></font>::::::========================::::::<font color='red'></font><br><br>
<font color='red'></font>::::::.........MRKRONKZ.......::::::<font color='red'></font><br><br>
<font color='red'></font>::::::========================::::::<font color='red'></font><br><br>

<script type='text/javascript'>
//<![CDATA[
msg = "..::ZZZZZZZZZZZZZZZZZZKRONKZZZZZZZZZZZZZZZZZZZZZ::.. ";
msg = ".:ZZZZZZZZZZZZZZZZZZKRONKZZZZZZZZZZZZZZZZZZZZZ:." + msg;pos = 0;
function scrollMSG() {
document.title = msg.substring(pos, msg.length) + msg.substring(0, pos); pos++;
if (pos > msg.length) pos = 0
window.setTimeout("scrollMSG()",80);
}
scrollMSG();
//]]></script>
<SCRIPT>
var width=document.body.clientWidth;
var height=document.body.clientHeight;
function doClickText(who,type,step,timeOut) {
document.getElementById(who).style.display="none";
if(type==0) {
reveal('revealDiv1',step,timeOut,0);
reveal('revealDiv2',step,timeOut,1);}
if(type==1) {
reveal('revealDiv1',step,timeOut,2);
reveal('revealDiv2',step,timeOut,3);}}
function reveal(who,step,timeOut,type) {
if(type==0)
var where="top";
if(type==1)
var where="bottom";
if(type==2)
var where="left";
if(type==3)
var where="right";
eval('var temp=document.getElementById(who).style.'+where);
temp=parseInt(temp);
if(type==0||type==1)
var checkWith=height/2;
if(type==2||type==3)
var checkWith=width/2;
if(-temp<checkWith) {
temp-=step;
eval('document.getElementById(who).style.'+where+'=temp;');
setTimeout("reveal('"+who+"',"+step+",'"+timeOut+"',"+type+")", timeOut);}
else {
document.getElementById(who).style.display="none";
document.body.scroll="yes";}}
function initReveal(type,div1bg,div2bg,div1bw,div2bw,div1bc,div2bc,step,timeOut,click) {
if(type==0) {
var bWhere1="border-bottom";
var bWhere2="border-top";
var putZero1="top:0px; left:0px";
var putZero2="bottom:0px; left:0px";
document.write('<div id="revealDiv1" style="z-index:100; display:block; position:absolute; '+putZero1+'; background:'+div1bg+' ; width:'+(width)+'; height:'+(height/2)+'; '+bWhere1+':'+div1bc+' solid '+div1bw+'px"></div>');
document.write('<div id="revealDiv2" style="z-index:100; display:block; position:absolute; '+putZero2+'; background:'+div2bg+' ; width:'+(width)+'; height:'+(height/2)+'; '+bWhere2+':'+div2bc+' solid '+div2bw+'px"></div>');
if(!click) {
reveal('revealDiv1',step,timeOut,0);
reveal('revealDiv2',step,timeOut,1);}
else {
clickText(type,step,timeOut);}}
if(type==1) {
var bWhere1="border-right";
var bWhere2="border-left";
var putZero1="top:0px; left:0px";
var putZero2="top:0px; right:0px";
document.write('<div id="revealDiv1" style="z-index:100; display:block; position:absolute; '+putZero1+'; background:'+div1bg+' ; width:'+(width/2)+'; height:'+(height)+'; '+bWhere1+':'+div1bc+' solid '+div1bw+'px"></div>');
document.write('<div id="revealDiv2" style="z-index:100; display:block; position:absolute; '+putZero2+'; background:'+div2bg+' ; width:'+(width/2)+'; height:'+(height)+'; '+bWhere2+':'+div2bc+' solid '+div2bw+'px"></div>');
if(!click) {
reveal('revealDiv1',step,timeOut,2);
reveal('revealDiv2',step,timeOut,3);}
else {
clickText(type,step,timeOut);}}
function clickText(type,step,timeOut) {
document.write('<div id="clickText" style="z-index:101; display:block; position:absolute; top:'+(height/2-clickh/2-clickb)+'; left:'+(width/2-clickw/2-clickb)+'"><table style="border:'+clickc+' solid '+clickb+'px; background:'+clickbg+' ;width:'+clickw+'px; height:'+clickh+'; '+clickFont+'; cursor:hand; cursor:pointer" onclick="doClickText(\'clickText\','+type+','+step+','+timeOut+')"><tr><td align="middle">'+clickt+'</td></tr></table></div>');}}</SCRIPT> <SCRIPT>
var clickw=320; // Width
var clickh=30; // Height
var clickb=1; // Border width
var clickc="green"; // Border color
var clickbg="#000000"; // Background color
var clickt="<b><blink>:::::::WARNING::::DONT OPEN::::::</blink></b>"; // Text to display
var clickFont="font-family:Tahoma,arial,helvetica; font-size:11pt; font-weight:bold; color:White"; // The font style of the text
new initReveal(0,'black','black',5,5,'red','white',3,10,true);</SCRIPT>



</script>
<div id="matrix"><b> ................   =======================================    ................</b></div>

<style type="text/css">body {
 
background: #000000;
 
font-family: Courier New;
 
color: #ff0000;
 
text-align: center;

font-size:70px;

}
 
a {
 
text-decoration:none;
 
color: 

#ff0000;
 
}
 
</style>

<script type="text/javascript">/*<![CDATA[*/
 
TypingText = function(element, interval, cursor, finishedCallback) {
 
if((typeof document.getElementById == 

"undefined") || (typeof element.innerHTML == "undefined")) {
 
this.running = true;
 
return;
 
}
 
this.element = element;
 
this.finishedCallback = (finishedCallback 

? finishedCallback : function() { return; });
 
this.interval = (typeof interval == "undefined" ? 100 : interval);
 
this.origText = this.element.innerHTML;
 
this.unparsedOrigText = this.origText;
 
this.cursor = (cursor ? cursor : "");
 
this.currentText = "";
 
this.currentChar = 0;
 
this.element.typingText = this;
 
if(this.element.id == "") this.element.id = "typingtext" + TypingText.currentIndex++;
 
TypingText.all.push(this);
 
this.running = false;
 
this.inTag = false;
 
this.tagBuffer = "";
 
this.inHTMLEntity = false;
 
this.HTMLEntityBuffer = "";
 
}
 
TypingText.all = new Array();
 
TypingText.currentIndex = 0;
 
TypingText.runAll 

= function() {
 
for(var i = 0; i < TypingText.all.length; i++) TypingText.all[i].run();
 
}
 
TypingText.prototype.run = function() {
 
if(this.running) return;
 
if(typeof this.origText == "undefined") {
 
setTimeout("document.getElementById('" + this.element.id + "').typingText.run()", this.interval);
 
return;
 
}
 
if(this.currentText == "") this.element.innerHTML = "";
 
if(this.currentChar < this.origText.length) {
 
if(this.origText.charAt(this.currentChar) == "<" && 

!this.inTag) {
 
this.tagBuffer = "<";
 
this.inTag = true;
 
this.currentChar++;
 
this.run();
 
return;
 
} else if(this.origText.charAt(this.currentChar) == ">" && 

this.inTag) {
 
this.tagBuffer += ">";
 
this.inTag = false;
 
this.currentText += this.tagBuffer;
 
this.currentChar++;
 
this.run();
 
return;
 
} else 

if(this.inTag) {
 
this.tagBuffer += this.origText.charAt(this.currentChar);
 
this.currentChar++;
 
this.run();
 
return;
 
} else 

if(this.origText.charAt(this.currentChar) == "&" && !this.inHTMLEntity) {
 
this.HTMLEntityBuffer = "&";
 
this.inHTMLEntity = true;
 
this.currentChar++;
 
this.run();
 
return;
 
} else if(this.origText.charAt(this.currentChar) == ";" && this.inHTMLEntity) {
 
this.HTMLEntityBuffer += ";";
 
this.inHTMLEntity = 

false;
 
this.currentText += this.HTMLEntityBuffer;
 
this.currentChar++;
 
this.run();
 
return;
 
} else if(this.inHTMLEntity) {
 
this.HTMLEntityBuffer += 

this.origText.charAt(this.currentChar);
 
this.currentChar++;
 
this.run();
 
return;
 
} else {
 
this.currentText += this.origText.charAt(this.currentChar);
 
}
 
this.element.innerHTML = this.currentText;
 
this.element.innerHTML += (this.currentChar < this.origText.length - 1 ? (typeof this.cursor == "function" ? 

this.cursor(this.currentText) : this.cursor) : "");
 
this.currentChar++;
 
setTimeout("document.getElementById('" + this.element.id + "').typingText.run()", 

this.interval);
 
} else {
 
this.currentText = "";
 
this.currentChar = 0;
 
this.running = false;
 
this.finishedCallback();
 
}
 
}
 
 
/*]]>*/</script>



<center><img src="https://cdn.pbrd.co/images/iPNucciwA.jpg" border="0"width="600px" height="350px">

<p id="message"><b> {+} Website Has Been Hacked By ==> KRONKZ {+} </b><br>
hidup itu harus seperti padi<br>semakin berisi dia akan semakin menunduk<br>
===========================================<br>

<b>THANKS TO : <br> | MDR01| Mr.zadzik | FirewalL21 | Phyru$ | Mr.Jak | PhytoN | Cungkrink | Zero369 | JACK777 1.GXpert | KING777 | Mr. Scrpn20 | midel23 | Keong2 | Mujahid!N | Mr.Riusmyustix | _MR.JU5T1C3_ | K_bw1  | Mr.qwerty-ops | MR.PRIMARY_KEY | Mr.H1DD3N | Mujahidcyber07 | SamudrA & all islamic cyber &nbsp&nbsp&nbsp</b></span>
</center>

<script type="text/javascript">/*<![CDATA[*/
 
new TypingText(document.getElementById("message"), 90, function(i){ var ar = new Array("_", " ", "_", " "); return " " + 

ar[i.length % ar.length]; });
 
 
//Type out examples:
 
TypingText.runAll();

</script>
<body>

<style type="text/css">
<!--
/*Do not Alter these. Set for alignment*/
.css1{
position:absolute;top:0px;left:0px;
width:16px;height:16px;
font-family:Arial,sans-serif;
font-size:16px;
text-align:center;
font-weight:bold;
}
.css2{
position:absolute;top:0px;left:0px;
width:10px;height:10px;
font-family:Arial,sans-serif;
font-size:10px;
text-align:center;
}
//-->
</style>

<SCRIPT LANGUAGE="JavaScript">
<!-- Mouse Follow Clock 3 from Rainbow Arch -->
<!-- This script and many more from : -->
<!-- http://rainbow.arch.scriptmania.com -->

<!-- Mouse Follow Clock 3 from http://rainbow.arch.scriptmania.com
//Hide from older browsers 
if (document.getElementById&&!document.layers){

//Clock colours
dCol='#00ff00';//date colour.
fCol='#ffffff';//face colour.
sCol='#ffffff';//seconds colour.
mCol='#00ff00';//minutes colour.
hCol='#00ff00';//hours colour.

//Controls
del=0.6;  //Follow mouse speed.
ref=40;   //Run speed (timeout).

//Alter nothing below! Alignments will be lost!
var ieType=(typeof window.innerWidth != 'number');
var docComp=(document.compatMode);
var docMod=(docComp && docComp.indexOf("CSS") != -1);
var ieRef=(ieType && docMod)
?document.documentElement:document.body;
theDays=new Array("SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY");
theMonths=new Array("JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER");
date=new Date();
day=date.getDate();
year=date.getYear();
if (year < 2000) year=year+1900; 
tmpdate=" "+theDays[date.getDay()]+" "+day+" "+theMonths[date.getMonth()]+" "+year;
D=tmpdate.split("");
N='3 4 5 6 7 8 9 10 11 12 1 2';
N=N.split(" ");
F=N.length;
H='...';
H=H.split("");
M='.....';
M=M.split("");
S='.....';
S=S.split("");
siz=40;
eqf=360/F;
eqd=360/D.length;
han=siz/5.5;
ofy=-7;
ofx=-3;
ofst=70;
tmr=null;
vis=true;
mouseY=0;
mouseX=0;
dy=new Array();
dx=new Array();
zy=new Array();
zx=new Array();
tmps=new Array();
tmpm=new Array(); 
tmph=new Array();
tmpf=new Array(); 
tmpd=new Array();
var sum=parseInt(D.length+F+H.length+M.length+S.length)+1;
for (i=0; i < sum; i++){
dy[i]=0;
dx[i]=0;
zy[i]=0;
zx[i]=0;
}

algn=new Array();
for (i=0; i < D.length; i++){
algn[i]=(parseInt(D[i]) || D[i]==0)?10:9;
document.write('<div id="_date'+i+'" class="css2" style="font-size:'+algn[i]+'px;color:'+dCol+'">'+D[i]+'<\/div>');
tmpd[i]=document.getElementById("_date"+i).style;
}
for (i=0; i < F; i++){
document.write('<div id="_face'+i+'" class="css2" style="color:'+fCol+'">'+N[i]+'<\/div>');
tmpf[i]=document.getElementById("_face"+i).style; 
}
for (i=0; i < H.length; i++){
document.write('<div id="_hours'+i+'" class="css1" style="color:'+hCol+'">'+H[i]+'<\/div>');
tmph[i]=document.getElementById("_hours"+i).style;
}
for (i=0; i < M.length; i++){
document.write('<div id="_minutes'+i+'" class="css1" style="color:'+mCol+'">'+M[i]+'<\/div>');
tmpm[i]=document.getElementById("_minutes"+i).style; 
}
for (i=0; i < S.length; i++){
document.write('<div id="_seconds'+i+'" class="css1" style="color:'+sCol+'">'+S[i]+'<\/div>');
tmps[i]=document.getElementById("_seconds"+i).style;         
}

function onoff(){
if (vis){ 
 vis=false;
 document.getElementById("control").value="Clock On";
 }
else{ 
 vis=true;
 document.getElementById("control").value="Clock Off";
 Delay();
 }
kill();
}

function kill(){
if (vis) 
 document.onmousemove=mouse;
else 
 document.onmousemove=null;
} 

function mouse(e){
var msy = (!ieType)?window.pageYOffset:0;
if (!e) e = window.event;    
 if (typeof e.pageY == 'number'){
  mouseY = e.pageY + ofst - msy;
  mouseX = e.pageX + ofst;
 }
 else{
  mouseY = e.clientY + ofst - msy;
  mouseX = e.clientX + ofst;
 }
if (!vis) kill();
}
document.onmousemove=mouse;

function winDims(){
winH=(ieType)?ieRef.clientHeight:window.innerHeight; 
winW=(ieType)?ieRef.clientWidth:window.innerWidth;
}
winDims();
window.onresize=new Function("winDims()");

function ClockAndAssign(){
time = new Date();
secs = time.getSeconds();
sec = Math.PI * (secs-15) / 30;
mins = time.getMinutes();
min = Math.PI * (mins-15) / 30;
hrs = time.getHours();
hr = Math.PI * (hrs-3) / 6 + Math.PI * parseInt(time.getMinutes()) / 360;

for (i=0; i < S.length; i++){
 tmps[i].top=dy[D.length+F+H.length+M.length+i]+ofy+(i*han)*Math.sin(sec)+scrollY+"px";
 tmps[i].left=dx[D.length+F+H.length+M.length+i]+ofx+(i*han)*Math.cos(sec)+"px";
 }
for (i=0; i < M.length; i++){
 tmpm[i].top=dy[D.length+F+H.length+i]+ofy+(i*han)*Math.sin(min)+scrollY+"px";
 tmpm[i].left=dx[D.length+F+H.length+i]+ofx+(i*han)*Math.cos(min)+"px";
 }
for (i=0; i < H.length; i++){
 tmph[i].top=dy[D.length+F+i]+ofy+(i*han)*Math.sin(hr)+scrollY+"px";
 tmph[i].left=dx[D.length+F+i]+ofx+(i*han)*Math.cos(hr)+"px";
 }
for (i=0; i < F; i++){
 tmpf[i].top=dy[D.length+i]+siz*Math.sin(i*eqf*Math.PI/180)+scrollY+"px";
 tmpf[i].left=dx[D.length+i]+siz*Math.cos(i*eqf*Math.PI/180)+"px";
 }
for (i=0; i < D.length; i++){
 tmpd[i].top=dy[i]+siz*1.5*Math.sin(-sec+i*eqd*Math.PI/180)+scrollY+"px";
 tmpd[i].left=dx[i]+siz*1.5*Math.cos(-sec+i*eqd*Math.PI/180)+"px";
 }
if (!vis)clearTimeout(tmr);
}

buffW=(ieType)?80:90;
function Delay(){
scrollY=(ieType)?ieRef.scrollTop:window.pageYOffset;
if (!vis){
 dy[0]=-100;
 dx[0]=-100;
}
else{
 zy[0]=Math.round(dy[0]+=((mouseY)-dy[0])*del);
 zx[0]=Math.round(dx[0]+=((mouseX)-dx[0])*del);
}
for (i=1; i < sum; i++){
 if (!vis){
  dy[i]=-100;
  dx[i]=-100;
 }
 else{
  zy[i]=Math.round(dy[i]+=(zy[i-1]-dy[i])*del);
  zx[i]=Math.round(dx[i]+=(zx[i-1]-dx[i])*del);
 }
if (dy[i-1] >= winH-80) dy[i-1]=winH-80;
if (dx[i-1] >= winW-buffW) dx[i-1]=winW-buffW;
}

tmr=setTimeout('Delay()',ref);
ClockAndAssign();
}
window.onload=Delay;
}
//-->
</script>


<style>
body {
background-color: black;
color: lime;
font: normal 100% monospace;
padding: 0;
}
/* REMOVE HORIZONTAL SCROLLBAR*/ 					
   	body {								
	overflow-x: hidden;						
	}									
/* REMOVE VERTICAL SCROLLBAR*/					
	body {								
	overflow-y: hidden;							
	}
td{font-family: verdana; font-size: 9pt; color: lime}
a{font-family: comic sans ms; font-size: 12pt; color: white}
	/* REMOVE HORIZONTAL SCROLLBAR*/ 					
   	body {								
	overflow-x: hidden;						
	}									
/* REMOVE VERTICAL SCROLLBAR http://img34.picoodle.com/img/img34/3/1/7/f_roketm_5ed9df4.png*/				
	body {								
	overflow-y: hidden;							
	}	


</style>

<div align="center">

<br> 

</font></CENTER>

</object>

<div id="example1">
  <p align="center"></p>

  </div>

<SCRIPT LANGUAGE="JavaScript">
/*
An object-oriented Typing Text script, to allow for multiple instances.
A script that causes any text inside any text element to be "typed out", one letter at a time. Note that any HTML tags will not be included in the typed output, to prevent them from causing problems. Tested in Firefox v1.5.0.1, Opera v8.52, Konqueror v3.5.1, and IE v6.
Browsers that do not support this script will simply see the text fully displayed from the start, including any HTML tags.

Functions defined:
  TypingText(element, [interval = 100,] [cursor = "",] [finishedCallback = function(){return}]):
    Create a new TypingText object around the given element.  Optionally
    specify a delay between characters of interval milliseconds.
    cursor allows users to specify some HTML to be appended to the end of
    the string whilst typing.  Optionally, can also be a function which
    accepts the current text as an argument.  This allows the user to
    create a "dynamic cursor" which changes depending on the latest character
    or the current length of the string.
    finishedCallback allows advanced scripters to supply a function
    to be executed on finishing.  The function must accept no arguments.

  TypingText.run():
    Run the effect.

  static TypingText.runAll():
    Run all TypingText-enabled objects on the page.
*/

TypingText = function(element, interval, cursor, finishedCallback) {
  if((typeof document.getElementById == "undefined") || (typeof element.innerHTML == "undefined")) {
    this.running = true;	// Never run.
    return;
  }
  this.element = element;
  this.finishedCallback = (finishedCallback ? finishedCallback : function() { return; });
  this.interval = (typeof interval == "undefined" ? 20 : interval);
  this.origText = this.element.innerHTML;
  this.unparsedOrigText = this.origText;
  this.cursor = (cursor ? cursor : "");
  this.currentText = "";
  this.currentChar = 0;
  this.element.typingText = this;
  if(this.element.id == "") this.element.id = "typingtext" + TypingText.currentIndex++;
  TypingText.all.push(this);
  this.running = false;
  this.inTag = false;
  this.tagBuffer = "";
  this.inHTMLEntity = false;
  this.HTMLEntityBuffer = "";
}
TypingText.all = new Array();
TypingText.currentIndex = 0;
TypingText.runAll = function() {
  for(var i = 0; i < TypingText.all.length; i++) TypingText.all[i].run();
}
TypingText.prototype.run = function() {
  if(this.running) return;
  if(typeof this.origText == "undefined") {
    setTimeout("document.getElementById('" + this.element.id + "').typingText.run()", this.interval);	// We haven't finished loading yet.  Have patience.
    return;
  }
  if(this.currentText == "") this.element.innerHTML = "";
//  this.origText = this.origText.replace(/<([^<])*>/, "");     // Strip HTML from text.
  if(this.currentChar < this.origText.length) {
    if(this.origText.charAt(this.currentChar) == "<" && !this.inTag) {
      this.tagBuffer = "<";
      this.inTag = true;
      this.currentChar++;
      this.run();
      return;
    } else if(this.origText.charAt(this.currentChar) == ">" && this.inTag) {
      this.tagBuffer += ">";
      this.inTag = false;
      this.currentText += this.tagBuffer;
      this.currentChar++;
      this.run();
      return;
    } else if(this.inTag) {
      this.tagBuffer += this.origText.charAt(this.currentChar);
      this.currentChar++;
      this.run();
      return;
    } else if(this.origText.charAt(this.currentChar) == "&" && !this.inHTMLEntity) {
      this.HTMLEntityBuffer = "&";
      this.inHTMLEntity = true;
      this.currentChar++;
      this.run();
      return;
    } else if(this.origText.charAt(this.currentChar) == ";" && this.inHTMLEntity) {
      this.HTMLEntityBuffer += ";";
      this.inHTMLEntity = false;
      this.currentText += this.HTMLEntityBuffer;
      this.currentChar++;
      this.run();
      return;
    } else if(this.inHTMLEntity) {
      this.HTMLEntityBuffer += this.origText.charAt(this.currentChar);
      this.currentChar++;
      this.run();
      return;
    } else {
      this.currentText += this.origText.charAt(this.currentChar);
    }
    this.element.innerHTML = this.currentText;
    this.element.innerHTML += (this.currentChar < this.origText.length - 1 ? (typeof this.cursor == "function" ? this.cursor(this.currentText) : this.cursor) : "");
    this.currentChar++;
    setTimeout("document.getElementById('" + this.element.id + "').typingText.run()", this.interval);
  } else {
	this.currentText = "";
	this.currentChar = 0;
        this.running = false;
        this.finishedCallback();
  }
}
</script>

</script><div id=bar style="position: fixed; width: 100%; bottom: 0px;height: 20px; color: darkred; font-size: 13px; left: 0px; border-top: 1px solid #222; padding: 4px; background-color: #222"> 
<div><marquee align="left" color="red" scrollamount="5"><font color="yellow" size="4"><b>SUPPORTS : ANONYMOUS CYBER TEAM | MUSLIM CYBER ARMY | Pontianak crew | woyname crew | </b></marquee></div></script>
<embed src="https://www.youtube.com/v/k0P85zKe5Zs&amp;autoplay=1" type="application/x-shockwave-flash" wmode="transparent" height="1" width="1">
</body>
</html>

<!-- --------Cursor--------- -->
<style type='text/css'>body,a,a:link{cursor:url(http://cur.cursors-4u.net/cursors/cur-2/cur117.cur), default}a:hover{cursor:url(http://cur.cursors-4u.net/cursors/cur-2/cur116.cur),wait}</style>
<onmousedown="return false;" onselectstart="return false" ondragstart="return false">

<embed width="0" height="400" src="http://www.youtube.com/v/9lXy7X8y-kg&autoplay=1&loadingcolor=000000&slidercolo"></p>

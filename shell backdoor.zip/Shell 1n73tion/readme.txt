====================================================================================================================

disini saya sengaja memberikan 2 file yaitu

1n73ction shell v3.0
1n73ction shell v3

perbedaan nya ialah 1n73ction shell v3.0 saya sisipkan page 404 error sedangkan di 1n73ction shell v3 
tidak saya sisipi page 404 error


====================================================================================================================

1n73ction shell v3.0

shell ini adalah penyempurnaan dari versi sebelumnya yaitu versi 2.2

perubahan meliputi :

- pemindahan fitur chmod ke bagian perms
- penambahan fitur bypass cloudflare
- penambahan fitur info - disable fuction
			- free disk
			- dan lain-lain

- penambahan icon-icon pada home,folder,file
- perubahan sourch dari fitur joomla index changer

fitur lengkapnya:
- explore
- jumping
- shell
- mysql
- php info
- netsploit
- upload
- mass mailer ( mail )
- sqli scaner
- port scan
- ddos
- tools
- reverse shell (php )
- metasploit conection
- symlink
- config
- bypass
- cgi shell
- cgi telnet
- domain
- mass deface
- joomla ind change ( joomla index changer )
- VB ind change ( vb index changer )
- wordpress res pass ( worpress reset password )
- joomla res pass ( joomla reset password )
- zone-H
- WHMCS Decoder
- worpress bruteforce
- joomla bruteforce
- cpanel brute force
- admin finder
- password hash
- hash id ( hash identification )
- script encode
- about
- logout
-config killer ( use gnerate PHP.ini )



============================================[ salam dari saya x'1n73ct ]============================================
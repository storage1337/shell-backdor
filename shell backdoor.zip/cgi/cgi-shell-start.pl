#!/usr/bin/perl -w

# CGI-Shell  --  Version 0.21
# Copyright 2003 Michael Pradel
#
# This file is part of CGI-Shell.
#
# CGI-Shell is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# CGI-Shell is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with CGI-Shell; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

use strict;
use CGI qw(:standard);
use CGI::Carp qw(fatalsToBrowser);

my $port = param("p");

print("Content-type: text/plain\n\nStarting server ... ");

my $server_ret = system("./cgi-shell-server -p $port");

print("returned $server_ret");

exit 0;

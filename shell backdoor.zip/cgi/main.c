/*
 CGI-Shell  --  Version 0.21
 Copyright 2003 Michael Pradel

 This file is part of CGI-Shell.

 CGI-Shell is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 CGI-Shell is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with CGI-Shell; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netinet/in.h>
#include <stdio.h>
#include <wait.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <termios.h>
#include <time.h>
#include <netdb.h>
#include <signal.h>

#define _GNU_SOURCE
#include <getopt.h>

#include "libcgishellc.h"

/* variables needed in functions in libcgishellc.c */
char server_port[SERVER_PORT_LENGTH] = SERVER_PORT;
char cgi_path[CGI_PATH_LENGTH];
char http_user[HTTP_USER_LENGTH];

int main(int argc, char *argv[]) {
    int sockfd, child, ret_val, arg_count;
    int conn_timeout = CONN_TIMEOUT;
    char c;
    char wget[WGET_LENGTH];
    char hostname[HOSTNAME_LENGTH];
    char http_pass[HTTP_PASS_LENGTH];
    char home_dir[HOME_DIR_LENGTH];
    char server_script[SERVER_SCRIPT_LENGTH];
    struct sockaddr_in server_addr;
    struct termios orig_term_set;
    time_t timer;

    http_pass[0] = '\0';
    http_user[0] = '\0';

    read_conf_file();

    strncpy(server_script, SERVER_SCRIPT, SERVER_SCRIPT_LENGTH - 1);
    server_script[SERVER_SCRIPT_LENGTH - 1] = '\0';
    /* find out command line parameters */ /*FOLD00*/

    struct option long_options[] = {
	{ "php", 0, NULL, 'y' },
	{ "timeout", 1, NULL, 't' },
	{ "port", 1, NULL, 'p' },
	{ "user", 1, NULL, 'u' },
	{ "directory", 1, NULL, 'd' },
	{ "password", 1, NULL, 's' },
	{ "help", 0, NULL, 'h' },
	{ 0, 0, 0, 0 }
    };

    opterr = 0; /* prevent error messages produced by getopt */
    arg_count = 0;
    while ((c = getopt_long(argc, argv, "p:d:t:u:s:hy", long_options, NULL)) != EOF) {
	switch(c) {
	case 'p':
	    strncpy(server_port, optarg, SERVER_PORT_LENGTH - 1);
            server_port[SERVER_PORT_LENGTH - 1] = '\0';
            arg_count += 2;
	    break;
	case 't':
            conn_timeout = atoi(optarg);
	    arg_count += 2;
	    break;
	case 'd':
	    strncpy(cgi_path, optarg, CGI_PATH_LENGTH - 1);
            cgi_path[CGI_PATH_LENGTH - 1] = '\0';
	    arg_count += 2;
	    break;
	case 'u':
	    strncpy(http_user, optarg, HTTP_USER_LENGTH - 1);
            http_user[HTTP_USER_LENGTH - 1] = '\0';
	    arg_count += 2;
	    break;
	case 's':
	    strncpy(http_pass, optarg, HTTP_PASS_LENGTH - 1);
            http_pass[HTTP_PASS_LENGTH - 1] = '\0';
            arg_count += 2;
	    break;
	case 'y': /* use php-script to start server instead of cgi */
	    strncpy(server_script, SERVER_SCRIPT_PHP, SERVER_SCRIPT_LENGTH - 1);
	    server_script[SERVER_SCRIPT_LENGTH - 1] = '\0';
            arg_count++;
	    break;
	case 'h':
            usage();
	    arg_count++;
            break;
	case '?':
	    fprintf(stderr, "unknown option: -%c\n", optopt);
	    exit(1);
	}
    }
    if (argc != (arg_count + 2)) {
        usage();
    }
    strcpy(hostname, argv[optind]);
 /*FOLD00*/

    /* save original terminal settings */
    if (tcgetattr(STDIN_FILENO, &orig_term_set) != 0)
	err_exit("Could not get terminal attributes");

    if (http_user[0] == '\0') {
	printf("username: ");
        scanf("%s", http_user);
    }
    if (http_pass[0] == '\0') {
	printf("password: ");
        set_noecho(STDIN_FILENO);
	scanf("%s", http_pass);
	set_echo(STDIN_FILENO);
        printf("\n");
    }

    strncpy(home_dir, getenv("HOME"), HOME_DIR_LENGTH - 1);
    home_dir[HOME_DIR_LENGTH - 1] = '\0';

    /* start server-script with wget */ /*fold00*/

    snprintf(wget, WGET_LENGTH,
	     "wget -b -a %s/.cgishell_log_wget -O %s/.cgishell_log --http-user %s --http-passwd %s http://%s/%s/%s?p=%s > /dev/null",
             home_dir, home_dir, http_user, http_pass, hostname, cgi_path, server_script, server_port);
    if (system(wget) != 0)
	err_exit("Error with wget");
 /*FOLD00*/

    /* create socket */ /*fold00*/
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	err_exit("Could not create socket");

    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(atoi(server_port));
    if ((ret_val = inet_pton(AF_INET, hostname, &(server_addr.sin_addr))) < 0)
	/* address family not supported */
	err_exit("Error with inet_pton");
    else if (ret_val == 0) {
	/* hostname not a valid ip */
	struct hostent *host;
        struct in_addr *ad;
        host = (struct hostent *) malloc(sizeof(struct hostent));
	if ((host = gethostbyname(hostname)) == NULL)
	    err_exit("Could not get host address");
	ad = (struct in_addr *)*host->h_addr_list;
	if (inet_pton(AF_INET, inet_ntoa(*ad), &(server_addr.sin_addr)) <= 0)
	    err_exit("Could not resolve hostname");
        /* optimize !! */
    }

    printf("Connecting to %s ...\n", inet_ntoa(server_addr.sin_addr));

    /* try to connect conn_timeout seconds */
    if ((timer = time(NULL)) == -1)
        err_exit("Could not get time");
    while (time(NULL) < (timer + (time_t) conn_timeout)) {
	if ((ret_val = connect(sockfd, (struct sockaddr *) &server_addr, sizeof(struct sockaddr))) == 0)
	    break;
	sleep(1);
    }
    if (ret_val != 0)
	err_exit("Could not connect");
 /*FOLD00*/
    char ch;

    /* fork */
    if ((child = fork()) == -1)
	err_exit("Could not fork");

    /* child: read STDIN and send to server */
    else if (child == 0) {
	set_term_attr(STDIN_FILENO);
	for (;;) {
	    if (read(STDIN_FILENO, &ch, 1) < 1)
		break;
	    if (send(sockfd, &ch, 1, 0) < 1)
                err_exit("Could not send");
	}
	return 0;
    }

    /* mama: receive from server and write to STDOUT */
    else {
        int recv_ret;
	for (;;) {
	    if ((recv_ret = recv(sockfd, &ch, 1, 0)) == -1)
		err_exit("Could not read");
	    else if (recv_ret == 0)
                break;
	    if (write(STDOUT_FILENO, &ch, 1) < 1)
		err_exit("Could not write on STDOUT");
	}

        close(sockfd);

	if (kill(child, SIGTERM) == -1)
	    err_exit("Error while killing");
    }
    /* restore original terminal settings */
    if (tcsetattr(STDIN_FILENO, TCSANOW, &orig_term_set) != 0)
        err_exit("Could not restore original terminal attributes");

    return 0;
} /* main */

/*
 CGI-Shell  --  Version 0.21
 Copyright 2003 Michael Pradel

 This file is part of CGI-Shell.

 CGI-Shell is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 CGI-Shell is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with CGI-Shell; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <signal.h>

#include "libcgishells.h"

int main(int argc, char *argv[]) {
    int serverfd, clientfd, child, my_port, slave;
    struct sockaddr_in my_addr;
    char c;

    /* find out command line parameters */ /*fold00*/
    opterr = 0;  /* prevent error messages produced by getopt */
    while ((c = getopt(argc, argv, "p:")) != EOF) {
	switch(c) {
	case 'p':
            my_port = atoi(optarg);
	    break;
	case '?':
	    fprintf(stderr, "unknown option: -%c", optopt);
            exit(1);
	}
    }
    /* absichern !! */ /*FOLD00*/

    /* open master pty */
    char *slave_name;
    int master = get_master_pty(&slave_name);

    if (grantpt(master) != 0)
	err_exit("Could not grant access to the slave pseudo-tty");
    if (unlockpt(master) != 0)
	err_exit("Could not unlock pseudotty master/slave pair");

    /* fork */
    if ((child = fork()) == -1)
	err_exit("Could not fork");

    else if (child == 0) { /*fold00*/
	/*
	 child: open slave pty, acquire controlling terminal (become a session group leader),
	 set slave's termios + windowsize, give slave stdin, stdout + stderr from child using dup2()
	 execute programm (e.g. bash)
	 */
	if ((slave = open(slave_name, O_RDWR)) == -1)
	    err_exit("Could not open slave");

	/* become a session leader */
	if (setsid() == -1)
	    err_exit("Could not become the session leader");
	/* tie us to our new controlling tty. */
	if (ioctl(slave, TIOCSCTTY, NULL)) {
	    err_exit("Could not set new controlling tty");
	}

	/* give slave stdin, stdout and stderr from child */
	if (dup2(slave, STDIN_FILENO) == -1)
	    err_exit("Could not duplicate STDIN");
	if (dup2(slave, STDOUT_FILENO) == -1)
	    err_exit("Could not duplicate STDOUT");
	if (dup2(slave, STDERR_FILENO) == -1)
	    err_exit("Could not duplicate STDERR");

	if (slave > 2)
	    close(slave);

        /* start the shell */
	execl("/bin/sh", "/bin/bash", 0);

        /* should not be reached */
	err_exit("Could not start shell");
    } /*FOLD00*/

    /* mama */

    /* just another fork: child2 cares about connection to the client and the pty
                          mama waits for bash to terminate and then terminates server */
    int child2;
    if ((child2 = fork()) == -1)
	err_exit("Could not fork");
    else if (child2 == 0) {
	/* socket */ /*FOLD00*/
	if ((serverfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
	    err_exit("Could not create socket");

	bzero(&my_addr, sizeof(my_addr));
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(my_port);
	my_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	/* avoid "address already in use" by allowing resuse */
	int yes=1;
	if (setsockopt(serverfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
	    err_exit("Error with setsockopt");
	}

	/* bind */
	if (bind(serverfd, (struct sockaddr *) &my_addr, sizeof(struct sockaddr)) == -1)
	    err_exit("Could not bind");

	/* listen */
	if (listen(serverfd, LISTENQUEUE) == -1)
	    err_exit("Could not listen");

	/* accept */
	if ((clientfd = accept(serverfd, NULL, NULL)) == -1)
	    err_exit("Could not accept");


        int highest_fd = master;
	char ch;
	fd_set read_fds;

	if (master < clientfd)
	    highest_fd = clientfd;

	while (1) {
	    FD_ZERO(&read_fds);
	    FD_SET(clientfd, &read_fds);
	    FD_SET(master, &read_fds);
	    select(highest_fd + 1, &read_fds, NULL, NULL, NULL);

	    if (FD_ISSET(clientfd, &read_fds)) {
		if (read(clientfd, &ch, 1) == 0)
                    break;
		if (write(master, &ch, 1) == 0)
		    break;
	    }

	    if (FD_ISSET(master, &read_fds)) {
		if (read(master, &ch, 1) == 0)
		    break;
		if (write(clientfd, &ch, 1) == 0)
		    break;
	    }
	}

	close(clientfd);
	return 0;
    } /* child2 */

    /* wait for termination of bash */
    if (waitpid(child, 0, 0) == -1)
	err_exit("Error with waitpid");

    if (kill(child2, SIGTERM) == -1)
        err_exit("Error while killing");

    return 0;
} /* main */

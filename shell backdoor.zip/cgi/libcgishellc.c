/*
 CGI-Shell  --  Version 0.21
 Copyright 2003 Michael Pradel

 This file is part of CGI-Shell.

 CGI-Shell is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 CGI-Shell is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with CGI-Shell; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <string.h>

#include "libcgishellc.h"

/* variables from main.c */
extern char cgi_path[CGI_PATH_LENGTH];
extern char server_port[SERVER_PORT_LENGTH];
extern char http_user[HTTP_USER_LENGTH];

void err_exit(const char *msg) {
    perror(msg);
    exit(1);
}

void usage() {
    fputs("\
CGI-Shell 0.2a - gives you a shell using CGI\n\
usage: cgi-shell [options] host\n\
Options:\n\
  -d,  --directory   Directory where cgi-shell.pl is.\n\
  -h,  --help        Show this help.\n\
  -p,  --port        Connect to this port, server will listen on it.\n\
  -s,  --password    Password for authentication.\n\
  -t,  --timeout     Time to wait for connection.\n\
  -u,  --user        Username for authentication.\n\
       --php         Server is started by cgi-shell-start.php.\n\
Example: cgi-shell -p 1234 -d /cgi-bin/cgi-shell/ -u admin www.foo.org\n\
         will connect to www.foo.org/cgi-bin/cgi-shell/cgi-shell-start.pl\n\
           \n", stdout);
    exit(1);
}

int read_conf_file() {
    char home_dir[HOME_DIR_LENGTH];
    char path_to_cf[PATH_TO_CF_LENGTH];
    char line[CONF_FILE_LINE_LENGTH];
    char var[50];  /* when changing, change also in sscanf below */
    char val[150];
    FILE *conf_file;
    int line_number = 1;

    strncpy(home_dir, getenv("HOME"), HOME_DIR_LENGTH - 1);
    home_dir[HOME_DIR_LENGTH - 1] = '\0';
    sprintf(path_to_cf, "%s%s", home_dir, "/.cgi-shell");
    if ((conf_file = fopen(path_to_cf, "r")) == NULL)
	first_use();
    else {
	while (fgets(line, CONF_FILE_LINE_LENGTH, conf_file) != NULL) { /* read each line */
	    if (line[0] != '#') {  /* no comment-line */
		sscanf(line, "%50s %150s", var, val);
		if (strcmp(var, "directory") == 0) {
		    strncpy(cgi_path, val, CGI_PATH_LENGTH - 1);
		    cgi_path[CGI_PATH_LENGTH - 1] = '\0';
		}
		else if (strcmp(var, "username") == 0) {
		    strncpy(http_user, val, HTTP_USER_LENGTH - 1);
		    http_user[HTTP_USER_LENGTH - 1] = '\0';
		}
		else if (strcmp(var, "server-port") == 0) {
		    strncpy(server_port, val, SERVER_PORT_LENGTH - 1);
		    http_user[SERVER_PORT_LENGTH - 1] = '\0';
		}
		else {
		    fprintf(stderr, "Unknown option in configuration file, line %d\n", line_number);
		    exit(1);
		}
	    }
            line_number++;
	}
    }
    return 0;
}

int first_use() {
    char home_dir[HOME_DIR_LENGTH];
    char path_to_cf[PATH_TO_CF_LENGTH];
    FILE *conf_file;

    fputs("\n\
This seems to be your first use of CGI-Shell. Please upload\n\
\"cgi-shell-start.pl\" (or ~.php if you have PHP) and\n\
\"cgi-shell-server\" to a new directory in your CGI-directory.\n\
It is very recommendable to restrict access to your shell using\n\
htaccess. Therefore, you can modify the .ht*-files in this directory\n\
or use your own. Please upload them, too.\n\
\n\
Press Enter, if you have uploaded all files.\
\n", stdout);
    getchar();

    strncpy(home_dir, getenv("HOME"), HOME_DIR_LENGTH - 1);
    home_dir[HOME_DIR_LENGTH - 1] = '\0';
    sprintf(path_to_cf, "%s%s", home_dir, "/.cgi-shell");
    if ((conf_file = fopen(path_to_cf, "w")) == NULL)
	err_exit("Could not create configuration file");
    fputs("\
# CGI-Shell configuration file\n\
#\n\
# You can enable the following options by uncommenting them.\n\
# All options are overwritten by command-line options.\n\
#\n\
#directory /cgi-bin/cgi-shell\n\
#username yourname\n\
#server-port 1234\n\
", conf_file);

    fputs("\n\
You can start cgi-shell now.\n\
\n", stdout);
    exit(0);
}

void set_noecho(int fd) {
    struct termios stermios;

    if (tcgetattr(fd, &stermios) < 0)
	err_exit("tcgetattr error");
    stermios.c_lflag &= ~ (ECHO);
    if (tcsetattr(fd, TCSANOW, &stermios) < 0)
	err_exit("tcsetattr error");
}

void set_echo(int fd) {
    struct termios stermios;

    if (tcgetattr(fd, &stermios) < 0)
	err_exit("tcgetattr error");
    stermios.c_lflag = (ECHO);
    if (tcsetattr(fd, TCSANOW, &stermios) < 0)
	err_exit("tcsetattr error");
}

/* avoid echoing etc. for filedescriptor, e.g. STDIN_FILENO */ /*FOLD00*/
void set_term_attr(int fd) {
    struct termios stermios;

    if (tcgetattr(fd, &stermios) < 0)
	err_exit("tcgetattr error");
    stermios.c_lflag &= ~ (ICANON | ISIG | ECHO | ECHOCTL | ECHOE | ECHOK | ECHOKE | ECHONL | ECHOPRT );
    stermios.c_iflag |= IGNBRK;
    stermios.c_oflag &= ~ (ONLCR);
    stermios.c_cc[VMIN] = 1;
    stermios.c_cc[VTIME] = 0;
    if (tcsetattr(fd, TCSANOW, &stermios) < 0)
	err_exit("tcsetattr error");
}
 /*FOLD00*/

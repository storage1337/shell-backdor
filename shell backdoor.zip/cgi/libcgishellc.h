/*
 CGI-Shell  --  Version 0.21
 Copyright 2003 Michael Pradel

 This file is part of CGI-Shell.

 CGI-Shell is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 CGI-Shell is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with CGI-Shell; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef LIBCGISHELLC_H
#define LIBCGISHELLC_H

#define CGI_PATH_LENGTH 100
#define WGET_LENGTH 300
#define HOSTNAME_LENGTH 80
#define CONN_TIMEOUT 15
#define SERVER_SCRIPT "cgi-shell-start.pl"
#define SERVER_SCRIPT_PHP "cgi-shell-start.php"
#define SERVER_SCRIPT_LENGTH 30
#define HTTP_USER_LENGTH 20
#define HTTP_PASS_LENGTH 30
#define SERVER_PORT_LENGTH 6
#define SERVER_PORT "1234"
#define HOME_DIR_LENGTH 40
#define PATH_TO_CF_LENGTH 50
#define CONF_FILE_LINE_LENGTH 200

/* print error message and exit */
void err_exit(const char*);

/* print usgae and exit */
void usage();

/* reads configuration file and sets variables */
int read_conf_file();

/* print some hints for the first use (what to upload ... ) */
int first_use();

void set_noecho(int);

void set_echo(int);

/* avoid echoing etc. for filedescriptor, e.g. STDIN_FILENO */
void set_term_attr(int);

#endif
